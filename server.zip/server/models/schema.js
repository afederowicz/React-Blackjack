/*
*
*
* Mongoose Middleware File/Set Up Schema 
*
*
*/

/* Import dependencies, require mongoose */



/* Set up database schema */

